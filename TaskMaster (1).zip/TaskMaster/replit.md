# Livestream Player with Custom Overlays

## Overview

A full-stack web application for streaming RTSP video feeds with customizable overlays. The system converts RTSP streams to HLS format for browser playback and allows users to add, position, and resize text and logo overlays on top of the video stream in real-time.

**Core Functionality:**
- RTSP to HLS video streaming conversion using FFmpeg
- Real-time overlay management (text and logo overlays)
- Drag-and-drop overlay positioning
- Resizable overlay components
- File upload for logo/image overlays
- Video playback controls (play, pause, volume)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework:** React 19 with Vite build tool

**Key Design Decisions:**
- **React with Vite:** Chosen for fast development experience with HMR (Hot Module Replacement) and modern ES module support
- **Component-based architecture:** Modular overlay components that can be independently manipulated
- **Client-side video playback:** Using HLS.js library for adaptive streaming support in the browser

**Core Libraries:**
- `hls.js` - HLS video playback in browsers that don't natively support it
- `react-draggable` - Provides drag functionality for overlay positioning
- `react-resizable` - Enables resizable overlay components
- `axios` - HTTP client for API communication

**Development Server:**
- Runs on port 5000
- Proxy configuration routes `/api` requests to backend on port 5001
- Configured for network access with `host: '0.0.0.0'`

### Backend Architecture

**Framework:** Flask (Python 3.11)

**Key Design Decisions:**
- **In-memory storage:** Overlays are stored in a Python dictionary for fast access and simplicity. This means overlays are not persisted between server restarts.
  - *Rationale:* Lightweight solution for real-time overlay management without database overhead
  - *Trade-off:* Data is ephemeral; overlays reset on server restart
  
- **RESTful API design:** Full CRUD operations for overlay management
  - GET `/api/overlays` - List all overlays
  - GET `/api/overlays/<id>` - Get specific overlay
  - POST `/api/overlays` - Create overlay
  - PUT `/api/overlays/<id>` - Update overlay
  - DELETE `/api/overlays/<id>` - Remove overlay

- **CORS enabled:** Flask-CORS allows cross-origin requests from the React frontend

- **File upload handling:** Dedicated uploads directory for logo/image storage

**Streaming Architecture:**
- FFmpeg subprocess for RTSP to HLS conversion
- Stream files stored in `stream/` directory
- Stream state managed in-memory with process tracking
- Robust process lifecycle management:
  - stdout/stderr redirected to DEVNULL to prevent pipe buffer blocking
  - Graceful termination with 5-second timeout, escalates to kill() if needed
  - Proper cleanup prevents zombie processes
  - State consistency maintained across start/stop/error scenarios

### Data Models

**Overlay Structure:**
```javascript
{
  id: "uuid-string",
  type: "text" | "logo",
  content: "string", // Text content or file path
  position: { x: number, y: number },
  size: { width: number, height: number },
  style: { fontSize: string, color: string, ... },
  created_at: "ISO timestamp"
}
```

**Stream Settings:**
```javascript
{
  rtsp_url: "string",
  is_streaming: boolean,
  stream_process: subprocess | null
}
```

### File Storage

**Directory Structure:**
- `stream/` - Temporary HLS segment files for video streaming
- `uploads/` - User-uploaded logo and image files

Both directories are created automatically on application startup if they don't exist.

## External Dependencies

### Third-party Services & Tools

**FFmpeg** (External binary, required)
- **Purpose:** RTSP stream to HLS conversion for browser compatibility
- **Integration:** Spawned as subprocess from Flask backend
- **Critical dependency:** Must be installed on the system; application cannot stream without it

### Python Packages

**Flask 3.0.0**
- Lightweight web framework for REST API
- Handles HTTP routing, request/response cycles

**Flask-CORS 4.0.0**
- Enables cross-origin resource sharing
- Required for React frontend (port 5000) to communicate with Flask backend (port 5001)

### JavaScript Packages

**Core Runtime:**
- `react` 19.1.1 - UI component library
- `react-dom` 19.1.1 - React rendering for web

**Video Streaming:**
- `hls.js` 1.6.13 - HTTP Live Streaming protocol support for browsers

**UI Interaction:**
- `react-draggable` 4.5.0 - Drag-and-drop overlay positioning
- `react-resizable` 3.0.5 - Resizable overlay components

**HTTP Client:**
- `axios` 1.12.2 - Promise-based HTTP client for API requests

**Build Tools:**
- `vite` 7.1.7 - Frontend build tool and dev server
- `@vitejs/plugin-react` 5.0.4 - React integration for Vite

### Development Dependencies

- ESLint configuration for code quality
- React type definitions for better IDE support
- No database dependencies (uses in-memory storage)

### Network Architecture

**Port Configuration:**
- Frontend dev server: Port 5000
- Backend API server: Port 5001
- API proxy: Frontend proxies `/api/*` requests to backend

**RTSP Stream Sources:**
- Application accepts any RTSP URL as input
- No specific streaming service dependency
- FFmpeg handles protocol conversion