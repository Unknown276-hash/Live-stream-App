# 🎥 Livestream Player with Custom Overlays

A full-stack web application for streaming RTSP video with customizable text and logo overlays. Built with Flask, React, and FFmpeg.

![Livestream Player](https://img.shields.io/badge/status-active-success)
![Python](https://img.shields.io/badge/python-3.11-blue)
![React](https://img.shields.io/badge/react-18-61DAFB)
![License](https://img.shields.io/badge/license-MIT-green)

## ✨ Features

- 📡 **RTSP Stream Playback** - Convert and play RTSP streams in the browser
- 🎨 **Custom Overlays** - Add text and logo overlays to your livestream
- 🖱️ **Drag & Resize** - Intuitive overlay positioning and sizing
- 🔧 **CRUD API** - Full REST API for overlay management
- 🎬 **Video Controls** - Play, pause, and volume adjustment
- 💾 **File Uploads** - Upload logos and images for overlays
- ⚡ **Real-time Updates** - Instant overlay synchronization

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- Node.js 20+
- FFmpeg

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd livestream-app
   ```

2. **Install dependencies**
   ```bash
   # Backend
   pip install -r requirements.txt

   # Frontend
   cd frontend
   npm install
   cd ..
   ```

3. **Start the application**
   ```bash
   bash start.sh
   ```

4. **Open your browser**
   ```
   http://localhost:5000
   ```

## 📖 Documentation

- **[API Documentation](API_DOCUMENTATION.md)** - Complete REST API reference
- **[User Guide](USER_DOCUMENTATION.md)** - How to use the application

## 🏗️ Architecture

### Backend (Flask)
- **Port**: 5001
- **Framework**: Flask with Flask-CORS
- **Streaming**: FFmpeg (RTSP to HLS conversion)
- **Storage**: In-memory overlay management

### Frontend (React)
- **Port**: 5000
- **Framework**: React with Vite
- **Video Player**: HLS.js
- **Overlay Editor**: react-draggable, react-resizable

### Tech Stack
```
┌─────────────────────────────────────┐
│         Frontend (React)            │
│    Port 5000 - User Interface       │
│  - HLS Video Player                 │
│  - Overlay Management UI            │
│  - Drag & Resize Controls           │
└─────────────────────────────────────┘
                 ↓ HTTP/WebSocket
┌─────────────────────────────────────┐
│         Backend (Flask)             │
│    Port 5001 - REST API             │
│  - CRUD Endpoints                   │
│  - File Upload                      │
│  - Stream Management                │
└─────────────────────────────────────┘
                 ↓ FFmpeg
┌─────────────────────────────────────┐
│         RTSP Stream                 │
│    Converted to HLS                 │
│  - H.264 Video                      │
│  - AAC Audio                        │
└─────────────────────────────────────┘
```

## 🎯 Usage

### 1. Start a Stream
Enter an RTSP URL and click "Start Stream"

```
rtsp://example.com/stream
```

### 2. Add Overlays
- **Text Overlay**: Click "+ Add Text Overlay"
- **Logo Overlay**: Click "+ Add Logo Overlay" and upload an image

### 3. Edit Overlays
- Click "Show Editor" to open the overlay editor
- Drag to reposition
- Resize using handles
- Modify text, color, and font size

### 4. Manage Overlays
- View all overlays in the active list
- Delete overlays individually
- Update positions and styles in real-time

## 🔌 API Endpoints

### Overlays
- `GET /api/overlays` - Get all overlays
- `POST /api/overlays` - Create overlay
- `GET /api/overlays/<id>` - Get specific overlay
- `PUT /api/overlays/<id>` - Update overlay
- `DELETE /api/overlays/<id>` - Delete overlay

### Streaming
- `POST /api/stream/start` - Start RTSP stream
- `POST /api/stream/stop` - Stop stream
- `GET /api/stream/status` - Get stream status

### File Management
- `POST /api/upload` - Upload logo file
- `GET /api/uploads/<filename>` - Serve uploaded file

See [API_DOCUMENTATION.md](API_DOCUMENTATION.md) for detailed API reference.

## 📁 Project Structure

```
.
├── backend/
│   ├── app.py              # Flask application
│   ├── stream/             # HLS stream output
│   └── uploads/            # Uploaded logo files
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── VideoPlayer.jsx
│   │   │   └── OverlayEditor.jsx
│   │   ├── App.jsx
│   │   └── App.css
│   ├── vite.config.js
│   └── package.json
├── requirements.txt
├── start.sh
├── README.md
├── API_DOCUMENTATION.md
└── USER_DOCUMENTATION.md
```

## 🧪 Testing

### Test RTSP Streams

Use these public RTSP streams for testing:

```
rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mp4
```

Or create your own using services like:
- rtsp.me
- RTSP Simple Server
- IP Camera Simulators

## 🛠️ Development

### Running Backend Only
```bash
cd backend
python app.py
```

### Running Frontend Only
```bash
cd frontend
npm run dev
```

### Building for Production
```bash
cd frontend
npm run build
```

## 🐛 Troubleshooting

### Stream not playing?
- Verify RTSP URL is accessible
- Check FFmpeg installation
- Review backend logs for errors

### Overlays not showing?
- Ensure backend is running (port 5001)
- Check browser console for errors
- Verify overlay positions are within video bounds

### File upload issues?
- Check file size and format
- Ensure `backend/uploads/` directory exists
- Verify backend permissions

See [USER_DOCUMENTATION.md](USER_DOCUMENTATION.md) for detailed troubleshooting.

## 🔐 Security Notes

- This is a development server - use a production WSGI server for deployment
- Implement authentication for production use
- Validate and sanitize RTSP URLs
- Set file upload size limits
- Use HTTPS in production

## 📝 Future Enhancements

- [ ] PostgreSQL database for persistent overlay storage
- [ ] User authentication and authorization
- [ ] Multiple overlay templates and presets
- [ ] Overlay animation and transitions
- [ ] Video recording and export
- [ ] Multi-stream support
- [ ] WebRTC support for lower latency

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- FFmpeg for video processing
- HLS.js for video playback
- React Draggable & Resizable for overlay controls

---

**Built with ❤️ using Flask, React, and FFmpeg**
