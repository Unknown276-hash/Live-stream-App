#!/bin/bash

# Start Flask backend in the background
cd backend && python app.py &

# Wait a bit for backend to start
sleep 2

# Start React frontend
cd frontend && npm run dev
