# Livestream Player with Custom Overlays - User Guide

## Table of Contents
1. [Overview](#overview)
2. [Installation & Setup](#installation--setup)
3. [Using the Application](#using-the-application)
4. [Managing Overlays](#managing-overlays)
5. [RTSP Stream Sources](#rtsp-stream-sources)
6. [Troubleshooting](#troubleshooting)

## Overview

The Livestream Player is a web application that allows you to:
- Stream video from RTSP sources
- Add custom text and logo overlays to the video
- Position and resize overlays in real-time
- Manage overlays using an intuitive editor

### Technology Stack
- **Backend**: Flask (Python)
- **Frontend**: React with Vite
- **Video Streaming**: FFmpeg (RTSP to HLS conversion)
- **Overlay Management**: In-memory storage with full CRUD API

## Installation & Setup

### Prerequisites
- Python 3.11
- Node.js 20
- FFmpeg

### Installation Steps

1. **Install Dependencies:**

   Backend:
   ```bash
   pip install -r requirements.txt
   ```

   Frontend:
   ```bash
   cd frontend
   npm install
   ```

2. **Start the Application:**

   Run both backend and frontend together:
   ```bash
   bash start.sh
   ```

   Or run them separately:
   
   Backend:
   ```bash
   cd backend
   python app.py
   ```
   
   Frontend:
   ```bash
   cd frontend
   npm run dev
   ```

3. **Access the Application:**
   
   Open your browser and navigate to:
   ```
   http://localhost:5000
   ```

## Using the Application

### 1. Starting a Stream

1. In the **Stream Setup** section, enter your RTSP URL
   - Example: `rtsp://example.com/stream`
   - For testing, use services like rtsp.me or similar

2. Click the **Start Stream** button

3. The video player will display the livestream once connected

4. Use the video controls to:
   - **Play/Pause** the stream
   - **Adjust volume** using the slider

### 2. Stopping a Stream

Click the **Stop Stream** button to terminate the current stream.

## Managing Overlays

### Adding Overlays

#### Text Overlay
1. Click **+ Add Text Overlay** button
2. Enter your text in the prompt
3. The text overlay will appear on the video

#### Logo Overlay
1. Click **+ Add Logo Overlay** button
2. Select an image file (PNG, JPG, GIF, SVG)
3. The logo will appear on the video

### Editing Overlays

1. Click the **Show Editor** button to open the overlay editor
2. In the editor:
   - **Drag** overlays to reposition them
   - **Resize** overlays using the resize handles
   - **Select** an overlay to edit its properties

3. For text overlays, you can modify:
   - Text content
   - Font size (12-72px)
   - Color (using color picker)

### Deleting Overlays

**Method 1: From the Overlay List**
- Click the **Delete** button next to an overlay in the list

**Method 2: From the Editor**
- Hover over an overlay in the editor
- Click the **×** button that appears

### Viewing Active Overlays

The **Active Overlays** section shows:
- Total number of overlays
- List of all overlays with their types (📝 text or 🖼️ logo)
- Quick delete option for each overlay

## RTSP Stream Sources

### Getting Test RTSP Streams

For testing purposes, you can use:

1. **rtsp.me** - Create temporary RTSP streams from video files
2. **RTSP Simple Server** - Set up your own RTSP server
3. **IP Camera Simulators** - Various online tools

### Example RTSP URLs

```
rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mp4
```

### Supported RTSP Formats

The application uses FFmpeg to convert RTSP streams to HLS format, supporting:
- H.264 video codec
- AAC audio codec
- Most standard RTSP configurations

## Troubleshooting

### Stream Not Playing

**Issue**: "Error starting stream" message appears

**Solutions**:
1. Verify the RTSP URL is correct
2. Check if the RTSP source is accessible
3. Ensure FFmpeg is installed correctly
4. Check backend logs for detailed error messages

### Overlays Not Appearing

**Issue**: Overlays don't show on the video

**Solutions**:
1. Ensure you've created overlays using the buttons
2. Check if overlays are positioned within the video area
3. Try refreshing the page
4. Verify the backend is running (port 5001)

### Video Player Issues

**Issue**: Black screen or no video

**Solutions**:
1. Check if the stream has started successfully
2. Look for browser console errors (F12 → Console)
3. Try a different RTSP source
4. Ensure your browser supports HLS playback

### File Upload Failures

**Issue**: Logo upload doesn't work

**Solutions**:
1. Check file size (large files may fail)
2. Use supported formats: PNG, JPG, GIF, SVG
3. Ensure backend upload directory exists
4. Check browser developer tools for error messages

## Advanced Features

### Custom Overlay Styling

Text overlays support custom styling:
- **Font Size**: 12px to 72px
- **Color**: Any hex color value
- **Position**: Precise pixel positioning
- **Size**: Custom width and height

### Overlay Positioning

- All positions are in pixels relative to video player
- X: Horizontal position from left
- Y: Vertical position from top

### HLS Streaming Details

The application converts RTSP to HLS with:
- 2-second segments
- 5-segment playlist
- Automatic segment cleanup
- Low-latency mode enabled

## API Integration

For programmatic access, see [API_DOCUMENTATION.md](API_DOCUMENTATION.md)

The REST API allows you to:
- Create, read, update, and delete overlays
- Control stream playback
- Upload logo files
- Check system health

## Tips & Best Practices

1. **Performance**:
   - Limit the number of overlays for better performance
   - Use optimized images for logos
   - Close streams when not in use

2. **Overlay Design**:
   - Use contrasting colors for text visibility
   - Position overlays in non-critical video areas
   - Test different sizes for optimal appearance

3. **Streaming**:
   - Use reliable RTSP sources
   - Monitor network connectivity
   - Restart stream if issues occur

## Support & Contact

For issues or questions:
1. Check the troubleshooting section
2. Review API documentation for technical details
3. Examine browser console and backend logs
4. Verify all dependencies are installed correctly

---

**Built with Flask, React, and FFmpeg**
