# API Documentation

## Base URL
```
http://localhost:5001/api
```

## Overlay Management Endpoints

### 1. Get All Overlays
**GET** `/api/overlays`

Returns a list of all overlays.

**Response:**
```json
[
  {
    "id": "uuid-string",
    "type": "text",
    "content": "Sample Text",
    "position": { "x": 100, "y": 100 },
    "size": { "width": 200, "height": 60 },
    "style": { "fontSize": "24px", "color": "#ffffff" },
    "created_at": "2025-10-14T05:56:50.123456"
  }
]
```

### 2. Get Single Overlay
**GET** `/api/overlays/<overlay_id>`

Returns a specific overlay by ID.

**Response:**
```json
{
  "id": "uuid-string",
  "type": "text",
  "content": "Sample Text",
  "position": { "x": 100, "y": 100 },
  "size": { "width": 200, "height": 60 },
  "style": { "fontSize": "24px", "color": "#ffffff" },
  "created_at": "2025-10-14T05:56:50.123456"
}
```

**Error Response (404):**
```json
{
  "error": "Overlay not found"
}
```

### 3. Create Overlay
**POST** `/api/overlays`

Creates a new overlay.

**Request Body:**
```json
{
  "type": "text",
  "content": "Your Text Here",
  "position": { "x": 50, "y": 50 },
  "size": { "width": 200, "height": 50 },
  "style": {
    "fontSize": "24px",
    "color": "#ffffff"
  }
}
```

**Response (201):**
```json
{
  "id": "generated-uuid",
  "type": "text",
  "content": "Your Text Here",
  "position": { "x": 50, "y": 50 },
  "size": { "width": 200, "height": 50 },
  "style": { "fontSize": "24px", "color": "#ffffff" },
  "created_at": "2025-10-14T05:56:50.123456"
}
```

**Overlay Types:**
- `text`: Text overlay
- `logo`: Image/logo overlay

### 4. Update Overlay
**PUT** `/api/overlays/<overlay_id>`

Updates an existing overlay.

**Request Body:**
```json
{
  "content": "Updated Text",
  "position": { "x": 150, "y": 150 },
  "size": { "width": 250, "height": 70 },
  "style": { "fontSize": "28px", "color": "#ff0000" }
}
```

**Response (200):**
```json
{
  "id": "overlay-id",
  "type": "text",
  "content": "Updated Text",
  "position": { "x": 150, "y": 150 },
  "size": { "width": 250, "height": 70 },
  "style": { "fontSize": "28px", "color": "#ff0000" },
  "updated_at": "2025-10-14T06:00:00.123456"
}
```

**Error Response (404):**
```json
{
  "error": "Overlay not found"
}
```

### 5. Delete Overlay
**DELETE** `/api/overlays/<overlay_id>`

Deletes an overlay.

**Response (200):**
```json
{
  "message": "Overlay deleted successfully"
}
```

**Error Response (404):**
```json
{
  "error": "Overlay not found"
}
```

## Stream Management Endpoints

### 6. Start Stream
**POST** `/api/stream/start`

Starts streaming from an RTSP URL.

**Request Body:**
```json
{
  "rtsp_url": "rtsp://example.com/stream"
}
```

**Response (200):**
```json
{
  "message": "Stream started successfully",
  "playlist_url": "/api/stream/playlist.m3u8"
}
```

**Error Response (400):**
```json
{
  "error": "RTSP URL is required"
}
```

**Error Response (500):**
```json
{
  "error": "Error message details"
}
```

### 7. Stop Stream
**POST** `/api/stream/stop`

Stops the current stream.

**Response (200):**
```json
{
  "message": "Stream stopped successfully"
}
```

### 8. Get Stream Status
**GET** `/api/stream/status`

Returns the current stream status.

**Response:**
```json
{
  "is_streaming": true,
  "rtsp_url": "rtsp://example.com/stream"
}
```

## File Upload Endpoints

### 9. Upload Logo
**POST** `/api/upload`

Uploads a logo file for use as an overlay.

**Request:**
- Content-Type: `multipart/form-data`
- Field name: `file`

**Response (201):**
```json
{
  "filename": "uuid-filename.png",
  "url": "/api/uploads/uuid-filename.png"
}
```

**Error Response (400):**
```json
{
  "error": "No file provided"
}
```

## Health Check

### 10. Health Check
**GET** `/api/health`

Returns the health status of the API.

**Response (200):**
```json
{
  "status": "healthy"
}
```

## Example Usage

### Using cURL

**Create a text overlay:**
```bash
curl -X POST http://localhost:5001/api/overlays \
  -H "Content-Type: application/json" \
  -d '{
    "type": "text",
    "content": "Live Now!",
    "position": {"x": 100, "y": 100},
    "size": {"width": 200, "height": 60},
    "style": {"fontSize": "24px", "color": "#ffffff"}
  }'
```

**Start a stream:**
```bash
curl -X POST http://localhost:5001/api/stream/start \
  -H "Content-Type: application/json" \
  -d '{"rtsp_url": "rtsp://example.com/stream"}'
```

**Upload a logo:**
```bash
curl -X POST http://localhost:5001/api/upload \
  -F "file=@/path/to/logo.png"
```

**Update an overlay:**
```bash
curl -X PUT http://localhost:5001/api/overlays/{overlay_id} \
  -H "Content-Type: application/json" \
  -d '{
    "position": {"x": 200, "y": 200},
    "style": {"fontSize": "32px", "color": "#ff0000"}
  }'
```

**Delete an overlay:**
```bash
curl -X DELETE http://localhost:5001/api/overlays/{overlay_id}
```

### Using JavaScript/Axios

```javascript
import axios from 'axios';

// Create an overlay
const createOverlay = async () => {
  const response = await axios.post('/api/overlays', {
    type: 'text',
    content: 'Live Now!',
    position: { x: 100, y: 100 },
    size: { width: 200, height: 60 },
    style: { fontSize: '24px', color: '#ffffff' }
  });
  return response.data;
};

// Start stream
const startStream = async (rtspUrl) => {
  const response = await axios.post('/api/stream/start', {
    rtsp_url: rtspUrl
  });
  return response.data;
};

// Upload logo
const uploadLogo = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  
  const response = await axios.post('/api/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
  return response.data;
};
```

## Notes

- All overlay positions and sizes are in pixels
- The stream is converted from RTSP to HLS format using FFmpeg
- Overlays are stored in-memory and will be lost on server restart
- Supported image formats for logos: PNG, JPG, GIF, SVG
- Maximum file size for uploads: No explicit limit (adjust server config as needed)
