import { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';

const VideoPlayer = ({ streamUrl, overlays }) => {
  const videoRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (!streamUrl || !videoRef.current) return;

    const video = videoRef.current;

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
      });

      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        console.log('Stream loaded successfully');
      });

      hls.on(Hls.Events.ERROR, (event, data) => {
        console.error('HLS error:', data);
      });

      return () => {
        hls.destroy();
      };
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = streamUrl;
    }
  }, [streamUrl]);

  const handlePlayPause = () => {
    const video = videoRef.current;
    if (video.paused) {
      video.play();
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleVolumeChange = (e) => {
    const video = videoRef.current;
    video.volume = e.target.value / 100;
  };

  return (
    <div className="video-container">
      <div className="video-wrapper">
        <video
          ref={videoRef}
          className="video-player"
          controls={false}
          muted
        />
        
        {overlays.map((overlay) => (
          <div
            key={overlay.id}
            className="video-overlay"
            style={{
              position: 'absolute',
              left: `${overlay.position.x}px`,
              top: `${overlay.position.y}px`,
              width: `${overlay.size.width}px`,
              height: `${overlay.size.height}px`,
              ...overlay.style,
              pointerEvents: 'none',
            }}
          >
            {overlay.type === 'text' ? (
              <div style={{ 
                fontSize: overlay.style.fontSize || '24px',
                color: overlay.style.color || 'white',
                fontWeight: 'bold',
                textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
                width: '100%',
                height: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
                {overlay.content}
              </div>
            ) : overlay.type === 'logo' ? (
              <img
                src={overlay.content}
                alt="Overlay"
                style={{ width: '100%', height: '100%', objectFit: 'contain' }}
              />
            ) : null}
          </div>
        ))}
      </div>

      <div className="video-controls">
        <button onClick={handlePlayPause} className="control-btn">
          {isPlaying ? '⏸ Pause' : '▶ Play'}
        </button>
        <div className="volume-control">
          <span>🔊</span>
          <input
            type="range"
            min="0"
            max="100"
            defaultValue="50"
            onChange={handleVolumeChange}
            className="volume-slider"
          />
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
