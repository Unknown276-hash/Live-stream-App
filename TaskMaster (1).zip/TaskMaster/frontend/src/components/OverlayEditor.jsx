import { useState } from 'react';
import Draggable from 'react-draggable';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const OverlayEditor = ({ overlays, onUpdateOverlay, onDeleteOverlay }) => {
  const [selectedOverlay, setSelectedOverlay] = useState(null);

  const handleDrag = (overlayId, e, data) => {
    const overlay = overlays.find(o => o.id === overlayId);
    if (overlay) {
      onUpdateOverlay(overlayId, {
        ...overlay,
        position: { x: data.x, y: data.y }
      });
    }
  };

  const handleResize = (overlayId, e, { size }) => {
    const overlay = overlays.find(o => o.id === overlayId);
    if (overlay) {
      onUpdateOverlay(overlayId, {
        ...overlay,
        size: { width: size.width, height: size.height }
      });
    }
  };

  const handleStyleChange = (overlayId, styleKey, value) => {
    const overlay = overlays.find(o => o.id === overlayId);
    if (overlay) {
      onUpdateOverlay(overlayId, {
        ...overlay,
        style: { ...overlay.style, [styleKey]: value }
      });
    }
  };

  const handleContentChange = (overlayId, content) => {
    const overlay = overlays.find(o => o.id === overlayId);
    if (overlay) {
      onUpdateOverlay(overlayId, {
        ...overlay,
        content: content
      });
    }
  };

  return (
    <div className="overlay-editor">
      <h3>Overlay Editor</h3>
      
      <div className="overlay-canvas">
        {overlays.map((overlay) => (
          <Draggable
            key={overlay.id}
            position={{ x: overlay.position.x, y: overlay.position.y }}
            onStop={(e, data) => handleDrag(overlay.id, e, data)}
          >
            <div
              className={`editable-overlay ${selectedOverlay === overlay.id ? 'selected' : ''}`}
              onClick={() => setSelectedOverlay(overlay.id)}
            >
              <ResizableBox
                width={overlay.size.width}
                height={overlay.size.height}
                onResize={(e, data) => handleResize(overlay.id, e, data)}
                minConstraints={[50, 30]}
                maxConstraints={[600, 400]}
              >
                <div className="overlay-content" style={{ ...overlay.style }}>
                  {overlay.type === 'text' ? (
                    <div style={{
                      fontSize: overlay.style.fontSize || '24px',
                      color: overlay.style.color || 'white',
                      fontWeight: 'bold',
                      textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
                      width: '100%',
                      height: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      {overlay.content}
                    </div>
                  ) : overlay.type === 'logo' ? (
                    <img
                      src={overlay.content}
                      alt="Overlay"
                      style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                    />
                  ) : null}
                </div>
              </ResizableBox>
              <button
                className="delete-overlay-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteOverlay(overlay.id);
                }}
              >
                ×
              </button>
            </div>
          </Draggable>
        ))}
      </div>

      {selectedOverlay && (
        <div className="overlay-properties">
          <h4>Overlay Properties</h4>
          {overlays.find(o => o.id === selectedOverlay)?.type === 'text' && (
            <>
              <div className="property-group">
                <label>Text Content:</label>
                <input
                  type="text"
                  value={overlays.find(o => o.id === selectedOverlay)?.content || ''}
                  onChange={(e) => handleContentChange(selectedOverlay, e.target.value)}
                />
              </div>
              <div className="property-group">
                <label>Font Size:</label>
                <input
                  type="number"
                  value={parseInt(overlays.find(o => o.id === selectedOverlay)?.style?.fontSize) || 24}
                  onChange={(e) => handleStyleChange(selectedOverlay, 'fontSize', `${e.target.value}px`)}
                  min="12"
                  max="72"
                />
              </div>
              <div className="property-group">
                <label>Color:</label>
                <input
                  type="color"
                  value={overlays.find(o => o.id === selectedOverlay)?.style?.color || '#ffffff'}
                  onChange={(e) => handleStyleChange(selectedOverlay, 'color', e.target.value)}
                />
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default OverlayEditor;
