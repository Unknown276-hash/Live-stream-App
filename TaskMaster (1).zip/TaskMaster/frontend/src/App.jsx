import { useState, useEffect } from 'react';
import axios from 'axios';
import VideoPlayer from './components/VideoPlayer';
import OverlayEditor from './components/OverlayEditor';
import './App.css';

function App() {
  const [rtspUrl, setRtspUrl] = useState('');
  const [streamUrl, setStreamUrl] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [overlays, setOverlays] = useState([]);
  const [showEditor, setShowEditor] = useState(false);

  useEffect(() => {
    fetchOverlays();
    checkStreamStatus();
  }, []);

  const fetchOverlays = async () => {
    try {
      const response = await axios.get('/api/overlays');
      setOverlays(response.data);
    } catch (error) {
      console.error('Error fetching overlays:', error);
    }
  };

  const checkStreamStatus = async () => {
    try {
      const response = await axios.get('/api/stream/status');
      setIsStreaming(response.data.is_streaming);
      if (response.data.is_streaming) {
        setStreamUrl('/api/stream/playlist.m3u8');
        setRtspUrl(response.data.rtsp_url);
      }
    } catch (error) {
      console.error('Error checking stream status:', error);
    }
  };

  const startStream = async () => {
    if (!rtspUrl) {
      alert('Please enter an RTSP URL');
      return;
    }

    try {
      const response = await axios.post('/api/stream/start', { rtsp_url: rtspUrl });
      setStreamUrl(response.data.playlist_url);
      setIsStreaming(true);
      alert('Stream started successfully!');
    } catch (error) {
      console.error('Error starting stream:', error);
      alert('Error starting stream. Please check the RTSP URL and try again.');
    }
  };

  const stopStream = async () => {
    try {
      await axios.post('/api/stream/stop');
      setIsStreaming(false);
      setStreamUrl('');
      alert('Stream stopped successfully!');
    } catch (error) {
      console.error('Error stopping stream:', error);
    }
  };

  const createTextOverlay = async () => {
    const text = prompt('Enter overlay text:');
    if (!text) return;

    try {
      const response = await axios.post('/api/overlays', {
        type: 'text',
        content: text,
        position: { x: 100, y: 100 },
        size: { width: 200, height: 60 },
        style: {
          fontSize: '24px',
          color: '#ffffff'
        }
      });
      setOverlays([...overlays, response.data]);
    } catch (error) {
      console.error('Error creating overlay:', error);
    }
  };

  const uploadLogo = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const uploadResponse = await axios.post('/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      const response = await axios.post('/api/overlays', {
        type: 'logo',
        content: uploadResponse.data.url,
        position: { x: 50, y: 50 },
        size: { width: 150, height: 150 },
        style: {}
      });

      setOverlays([...overlays, response.data]);
    } catch (error) {
      console.error('Error uploading logo:', error);
    }
  };

  const updateOverlay = async (overlayId, updatedOverlay) => {
    try {
      const response = await axios.put(`/api/overlays/${overlayId}`, updatedOverlay);
      setOverlays(overlays.map(o => o.id === overlayId ? response.data : o));
    } catch (error) {
      console.error('Error updating overlay:', error);
    }
  };

  const deleteOverlay = async (overlayId) => {
    try {
      await axios.delete(`/api/overlays/${overlayId}`);
      setOverlays(overlays.filter(o => o.id !== overlayId));
    } catch (error) {
      console.error('Error deleting overlay:', error);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>🎥 Livestream Player with Custom Overlays</h1>
      </header>

      <div className="main-container">
        <div className="stream-setup">
          <h2>Stream Setup</h2>
          <div className="input-group">
            <input
              type="text"
              placeholder="Enter RTSP URL (e.g., rtsp://example.com/stream)"
              value={rtspUrl}
              onChange={(e) => setRtspUrl(e.target.value)}
              className="rtsp-input"
              disabled={isStreaming}
            />
            {!isStreaming ? (
              <button onClick={startStream} className="btn btn-primary">
                Start Stream
              </button>
            ) : (
              <button onClick={stopStream} className="btn btn-danger">
                Stop Stream
              </button>
            )}
          </div>
          
          {isStreaming && (
            <div className="stream-info">
              <span className="status-indicator"></span>
              <span>Streaming: {rtspUrl}</span>
            </div>
          )}
        </div>

        <div className="content-wrapper">
          <div className="video-section">
            <h2>Video Player</h2>
            {streamUrl ? (
              <VideoPlayer streamUrl={streamUrl} overlays={overlays} />
            ) : (
              <div className="no-stream">
                <p>No stream available. Please start a stream to view content.</p>
                <p className="hint">Tip: Use a test RTSP stream from rtsp.me or similar service</p>
              </div>
            )}
          </div>

          <div className="overlay-section">
            <div className="overlay-controls">
              <h2>Overlay Management</h2>
              <div className="button-group">
                <button onClick={createTextOverlay} className="btn btn-secondary">
                  + Add Text Overlay
                </button>
                <label className="btn btn-secondary">
                  + Add Logo Overlay
                  <input
                    type="file"
                    accept="image/*"
                    onChange={uploadLogo}
                    style={{ display: 'none' }}
                  />
                </label>
                <button
                  onClick={() => setShowEditor(!showEditor)}
                  className="btn btn-info"
                >
                  {showEditor ? 'Hide Editor' : 'Show Editor'}
                </button>
              </div>
            </div>

            {overlays.length > 0 && (
              <div className="overlay-list">
                <h3>Active Overlays ({overlays.length})</h3>
                <ul>
                  {overlays.map(overlay => (
                    <li key={overlay.id}>
                      <span>
                        {overlay.type === 'text' ? '📝' : '🖼️'} {overlay.content.substring(0, 30)}
                      </span>
                      <button
                        onClick={() => deleteOverlay(overlay.id)}
                        className="btn-small btn-danger"
                      >
                        Delete
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {showEditor && overlays.length > 0 && (
              <OverlayEditor
                overlays={overlays}
                onUpdateOverlay={updateOverlay}
                onDeleteOverlay={deleteOverlay}
              />
            )}
          </div>
        </div>
      </div>

      <footer className="app-footer">
        <p>Built with Flask, React, and FFmpeg | RTSP to HLS Livestream Player</p>
      </footer>
    </div>
  );
}

export default App;
