from flask import Flask, request, jsonify, Response, send_from_directory
from flask_cors import CORS
import subprocess
import threading
import os
import uuid
from datetime import datetime

app = Flask(__name__)
CORS(app)

# In-memory storage for overlays
overlays = {}

# Storage for stream settings
stream_settings = {
    'rtsp_url': '',
    'is_streaming': False,
    'stream_process': None
}

# Ensure directories exist
os.makedirs('stream', exist_ok=True)
os.makedirs('uploads', exist_ok=True)

# CRUD API Endpoints for Overlays

@app.route('/api/overlays', methods=['GET'])
def get_overlays():
    """Get all overlays"""
    return jsonify(list(overlays.values())), 200

@app.route('/api/overlays/<overlay_id>', methods=['GET'])
def get_overlay(overlay_id):
    """Get a specific overlay by ID"""
    if overlay_id in overlays:
        return jsonify(overlays[overlay_id]), 200
    return jsonify({'error': 'Overlay not found'}), 404

@app.route('/api/overlays', methods=['POST'])
def create_overlay():
    """Create a new overlay"""
    data = request.json
    
    overlay_id = str(uuid.uuid4())
    overlay = {
        'id': overlay_id,
        'type': data.get('type', 'text'),  # 'text' or 'logo'
        'content': data.get('content', ''),
        'position': data.get('position', {'x': 50, 'y': 50}),
        'size': data.get('size', {'width': 200, 'height': 50}),
        'style': data.get('style', {}),
        'created_at': datetime.now().isoformat()
    }
    
    overlays[overlay_id] = overlay
    return jsonify(overlay), 201

@app.route('/api/overlays/<overlay_id>', methods=['PUT'])
def update_overlay(overlay_id):
    """Update an existing overlay"""
    if overlay_id not in overlays:
        return jsonify({'error': 'Overlay not found'}), 404
    
    data = request.json
    overlay = overlays[overlay_id]
    
    # Update fields if provided
    if 'content' in data:
        overlay['content'] = data['content']
    if 'position' in data:
        overlay['position'] = data['position']
    if 'size' in data:
        overlay['size'] = data['size']
    if 'style' in data:
        overlay['style'] = data['style']
    
    overlay['updated_at'] = datetime.now().isoformat()
    overlays[overlay_id] = overlay
    
    return jsonify(overlay), 200

@app.route('/api/overlays/<overlay_id>', methods=['DELETE'])
def delete_overlay(overlay_id):
    """Delete an overlay"""
    if overlay_id not in overlays:
        return jsonify({'error': 'Overlay not found'}), 404
    
    del overlays[overlay_id]
    return jsonify({'message': 'Overlay deleted successfully'}), 200

# Stream Management Endpoints

@app.route('/api/stream/start', methods=['POST'])
def start_stream():
    """Start streaming from RTSP URL"""
    data = request.json
    rtsp_url = data.get('rtsp_url')
    
    if not rtsp_url:
        return jsonify({'error': 'RTSP URL is required'}), 400
    
    # Stop existing stream if running
    if stream_settings['stream_process']:
        process = stream_settings['stream_process']
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        stream_settings['stream_process'] = None
    
    # Reset streaming state
    stream_settings['is_streaming'] = False
    
    # Clean up old stream files
    for file in os.listdir('stream'):
        if file.endswith('.ts') or file.endswith('.m3u8'):
            os.remove(os.path.join('stream', file))
    
    try:
        # Start FFmpeg process to convert RTSP to HLS
        cmd = [
            'ffmpeg',
            '-rtsp_transport', 'tcp',
            '-i', rtsp_url,
            '-c:v', 'copy',
            '-c:a', 'aac',
            '-f', 'hls',
            '-hls_time', '2',
            '-hls_list_size', '5',
            '-hls_flags', 'delete_segments',
            '-hls_segment_filename', 'stream/segment%d.ts',
            'stream/playlist.m3u8'
        ]
        
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        stream_settings['rtsp_url'] = rtsp_url
        stream_settings['is_streaming'] = True
        stream_settings['stream_process'] = process
        
        return jsonify({
            'message': 'Stream started successfully',
            'playlist_url': '/api/stream/playlist.m3u8'
        }), 200
        
    except Exception as e:
        stream_settings['is_streaming'] = False
        return jsonify({'error': str(e)}), 500

@app.route('/api/stream/stop', methods=['POST'])
def stop_stream():
    """Stop the current stream"""
    if stream_settings['stream_process']:
        process = stream_settings['stream_process']
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        stream_settings['stream_process'] = None
    
    stream_settings['is_streaming'] = False
    return jsonify({'message': 'Stream stopped successfully'}), 200

@app.route('/api/stream/status', methods=['GET'])
def stream_status():
    """Get current stream status"""
    return jsonify({
        'is_streaming': stream_settings['is_streaming'],
        'rtsp_url': stream_settings['rtsp_url']
    }), 200

@app.route('/api/stream/<path:filename>')
def serve_stream(filename):
    """Serve HLS stream files"""
    return send_from_directory('stream', filename)

# File upload endpoint for logos
@app.route('/api/upload', methods=['POST'])
def upload_file():
    """Upload a logo file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Save file
    filename = str(uuid.uuid4()) + '_' + file.filename
    filepath = os.path.join('uploads', filename)
    file.save(filepath)
    
    return jsonify({
        'filename': filename,
        'url': f'/api/uploads/{filename}'
    }), 201

@app.route('/api/uploads/<filename>')
def serve_upload(filename):
    """Serve uploaded files"""
    return send_from_directory('uploads', filename)

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy'}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
